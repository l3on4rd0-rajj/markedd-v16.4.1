**strong text\[**\]

**strong text\\[**\]

**strong text\\\[**\]

**strong text\\\\[**\]

__strong text\[__\]

__strong text\\[__\]

__strong text\\\[__\]

__strong text\\\\[__\]

*em\[pha\]\(sis\)*

_em\[pha\]\(sis\)_

*\\*

_\\_


