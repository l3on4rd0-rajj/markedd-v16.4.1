---
pedantic: true
---
* test
+ test
- test
