(See https://www.example.com/fhqwhgads.)

((http://foo.com))

((http://foo.com.))

HTTP://FOO.COM

hTtP://fOo.CoM

~~hello@email.com~~

**me@example.com**

__test@test.com__

www.example.com

Www.example.com

WWW.example.com

(See hTtPS://example.com/fhqwhgads.)
