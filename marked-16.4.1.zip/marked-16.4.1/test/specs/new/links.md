Link: [constructor][].

[One](https://example.com/1) ([Two](https://example.com/2)) [Three](https://example.com/3)

[constructor]: https://example.org/
