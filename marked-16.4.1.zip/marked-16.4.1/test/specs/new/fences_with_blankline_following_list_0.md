1. code with blankline
```
if {

}
```

2. code and text
```
if {


}
```
text after fenced code block.

3. tilde
~~~
if {

}
~~~
