* Table in list:

  | column1 | column2 |
  |---------|---------|
  | value1  | value2  |
  | value3  | value4  |

* No leading pipe table in list:

  column1 | column2
  --------|--------
  value1  | value2
  value3  | value4
