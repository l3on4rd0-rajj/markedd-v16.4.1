**You might think this should be bold, but: `**`

**You might think this should be bold, but: ``**``

**You might think this should be bold, but: ```**```

**You might think this should be bold, but: ````**````

**This should be bold** and `this should be code`

**start `contains **` end**

**This should be bold ``**`

**This should be bold `**``

**start ``contains **`` end**
