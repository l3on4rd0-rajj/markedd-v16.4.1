*italics*

**bold**

***bold italics***

`*quoted italics*`

`**quoted bold**`

`***quoted bold italics***`

\`*escaped quoted italics*\`

\`**escaped quoted bold**\`

\`***escaped quoted bold italics***\`
