[link](foo(bar())

[link](foo\(bar())

[link](foo(bar\())

[link](foo(bar\\())
