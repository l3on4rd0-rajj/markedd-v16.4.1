_[test](https://example.com?link=with_(underscore))_
