| abc | def |
| --- | --- |
| bar | foo |
| baz | boo |
___

| abc | def |
| --- | --- |
| bar | foo |
| baz | boo |
---

text then table
| abc | def |
| --- | --- |
| bar | foo |
| baz | boo |
---
