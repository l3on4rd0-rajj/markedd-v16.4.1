[foo\
bar]

[foo\
bar]: https://example.com

[foo2\
bar2](https://example2.com)

[foo3\
bar3][foo\
bar]
