- list item 1
- list item 2
<div class="some-class">
Content
</div>

- list item 1
- list item 2
<!--
Comment
-->
