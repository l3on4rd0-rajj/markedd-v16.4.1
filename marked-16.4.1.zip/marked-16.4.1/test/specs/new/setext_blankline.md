a
 
b
 
=

a
 
b
 
-
