module.exports = {
  markdown: `a${' '.repeat(50000)}`,
  html: `<p>a${' '.repeat(50000)}</p>`,
};
